package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TableLayout;
import android.widget.TableRow;

import androidx.appcompat.app.AppCompatActivity;

public class BMICalculatorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmicalculator);


        EditText heightInput = findViewById(R.id.editTextHeight);
        EditText weightInput = findViewById(R.id.editTextWeight);
        Button calculateButton = findViewById(R.id.buttonCalculate);
        TextView resultText = findViewById(R.id.textViewResult);
        TextView statusText = findViewById(R.id.textViewStatus);

        RadioGroup radioGroupHeightUnit = findViewById(R.id.radioGroupHeightUnit);
        RadioButton radioCm = findViewById(R.id.radioCm);
        RadioButton radioFeetInches = findViewById(R.id.radioFeetInches);


        TableLayout tableBmiStatus = findViewById(R.id.tableBmiStatus);


        calculateButton.setOnClickListener(v -> {
            try {
                float weightKg = Float.parseFloat(weightInput.getText().toString());

                float heightCm = 0;

                if (radioCm.isChecked()) {
                    heightCm = Float.parseFloat(heightInput.getText().toString());
                } else if (radioFeetInches.isChecked()) {
                    String heightText = heightInput.getText().toString().trim();
                    if (heightText.matches("\\d+\'\\d+")) {
                        String[] heightParts = heightText.split("'");
                        int feet = Integer.parseInt(heightParts[0].trim());
                        int inches = Integer.parseInt(heightParts[1].trim());
                        heightCm = (feet * 30.48f) + (inches * 2.54f);
                    } else {
                        throw new Exception("Please enter height in 'X'Y format (e.g., 5'6).");
                    }
                } else {
                    throw new Exception("Please select a height unit.");
                }

                float heightM = heightCm / 100;
                float bmi = weightKg / (heightM * heightM);
                resultText.setText(String.format("Your BMI is: %.2f", bmi));

                // Set BMI status
                String status;
                if (bmi < 18.5) {
                    status = "Underweight";
                    statusText.setText(status);
                } else if (bmi >= 18.5 && bmi < 24.9) {
                    status = "Normal weight";
                    statusText.setText(status);
                } else if (bmi >= 25 && bmi < 29.9) {
                    status = "Overweight";
                    statusText.setText(status);
                } else {
                    status = "Obese";
                    statusText.setText(status);
                }

                // Update the table with BMI and Status
                updateBmiStatusTable(tableBmiStatus, bmi, status);

            } catch (Exception e) {
                resultText.setText("Please enter valid numbers.");
                statusText.setText("");
            }
        });
    }

    private void updateBmiStatusTable(TableLayout tableBmiStatus, float bmi, String status) {

        tableBmiStatus.removeAllViews();

        TableRow row = new TableRow(this);

        TextView bmiValue = new TextView(this);
        bmiValue.setText(String.format("%.2f", bmi));
        bmiValue.setPadding(16, 8, 16, 8);
        row.addView(bmiValue);

        TextView statusValue = new TextView(this);
        statusValue.setText(status);
        statusValue.setPadding(16, 8, 16, 8);
        row.addView(statusValue);

        tableBmiStatus.addView(row);
    }
}
